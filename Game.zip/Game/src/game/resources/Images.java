package game.resources;

import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Images {
    
    public static BufferedImage[] blocks;
    
    public Images(){
        blocks = new BufferedImage[8];
        try{
            blocks[0] = ImageIO.read(getClass().getResourceAsStream("/Blocks/City.png"));
            blocks[1] = ImageIO.read(getClass().getResourceAsStream("/Blocks/MenuBG.jpg"));
            blocks[2] = ImageIO.read(getClass().getResourceAsStream("/Blocks/Pengu.png"));
            blocks[3] = ImageIO.read(getClass().getResourceAsStream("/Blocks/Forest.png"));
            blocks[4] = ImageIO.read(getClass().getResourceAsStream("/Blocks/Ice.png"));
            blocks[5] = ImageIO.read(getClass().getResourceAsStream("/Blocks/Lava.png"));
            blocks[6] = ImageIO.read(getClass().getResourceAsStream("/Blocks/Desert.png"));
            blocks[7] = ImageIO.read(getClass().getResourceAsStream("/Blocks/Cloud.png"));
        } catch (IOException e){
            e.printStackTrace();
        }
    }
}
